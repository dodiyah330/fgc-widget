# FGC WebSocket server patch — deployment for testing

This package fixes the pending-incident count and the lost/delayed notification
behaviour in the FGC widget. All corrections are in a single file.

## What to deploy

| File | Action |
| --- | --- |
| `src/WebSocketServer.php` | **Replace** the existing file in the Symfony app. This is the only change. |
| `src/Command/WebSocketServerCommand.php` | **Reference only — identical to your current file.** Included so you can confirm nothing else changed. Do not deploy separately. |

> Please back up your current `src/WebSocketServer.php` before replacing it.

## Deploy steps

1. Copy `src/WebSocketServer.php` from this package over
   `src/WebSocketServer.php` in the Symfony project on the server.
2. Restart the WebSocket process so the new code is loaded:

   ```bash
   # however app:websocket-server is managed (supervisor / systemd / manual)
   php bin/console app:websocket-server
   # or: supervisorctl restart app-websocket-server
   #     systemctl restart <your-websocket-unit>
   ```

3. Confirm the startup log line still prints and the port is up on `8080`.

No database migration, no config change, and no new dependency is required. The
process keeps listening directly on port 8080 with Ratchet keepalive at 30s,
exactly as before.

## What changed in WebSocketServer.php

1. **Count now matches the CMS exactly.** It mirrors
   `AlertRepository::getTotalAlerts()` — pending state and excluding the `prova`
   test user. The old query additionally excluded edited (`updatedAt`) and
   CMS-created (`fromCms`) alerts, so the widget and “Alertes pendents” could
   disagree.
2. **Fresh authoritative count on every connect/reconnect.** The old code could
   send a value up to 14 seconds old, or nothing before the first cycle.
3. **`sync` and `ping` replies are private.** The old code broadcast every
   message type to every widget, which legacy widgets read as a new alert.
4. **Only `stop_alerts` is broadcast to all widgets.**
5. **Notify only when the count increases.** Resolving an incident (count goes
   down) no longer replays sound/blinking.
6. **A widget connecting between polls no longer silences the others.** Connect
   and sync do not touch the shared broadcast baseline.
7. **Database errors in the polling timer are caught and contained**, so a query
   failure can no longer terminate the process and drop every widget.
8. **Polling interval reduced from 14s to 2s** (`POLL_INTERVAL_SECONDS`), so new
   incidents reach connected widgets within ~2 seconds. Raise this one constant
   if the extra COUNT query is a concern.

## Optional: verify the logic before deploying

If PHP is available on the server or locally:

```bash
php -l src/WebSocketServer.php
php tests/server-websocket-smoke.php   # prints "WebSocketServer smoke tests passed."
```

The smoke test uses in-memory fakes and does not touch the database or network.

## After deploy — acceptance check

1. Open the widget. Its number must equal the CMS **Alertes pendents** total.
2. Send an alert from the FGC app with description `test`; the widget should
   rise by 1 within ~2 seconds and blink/sound once.
3. Resolve that alert in the CMS; the widget count drops with **no** new sound.
4. Leave the widget idle 20+ minutes and confirm no repeating disconnect.
5. Delete only the `test` alerts afterwards.
